<?php 
session_start();
include 'common/connect.php';

$volunteer_id =  $_SESSION['volunteer_id'];
$result = $obj->query("SELECT * FROM volunteer_acceptance WHERE user_id = '$volunteer_id' ");
?>

<!doctype html>
<html lang="zxx">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Helping-Hand(NGO)</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <!-- Template CSS -->
</head>

<body>
    <!--w3l-header-->
    <?php include 'common/header.php'; ?>
    <!--/header-->
    <div class="inner-banner"></div>
    <!-- /contact-form -->
    <section class="w3l-contact-11">
        <div class="form-41-mian py-5">
            <div class="container py-lg-4">
                <div class="row align-form-map">
                    <div class="col-lg-12 form-inner-cont">
                        <div class="title-content text-left">
                            <h3 class="hny-title mb-lg-5 mb-4">My donation post</h3>
                        </div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Application Post No.</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Date - time</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Campaign Creation</th>
                                    <th scope="col">Campaign Delivery Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = $result->fetch_object()) { ?>  
                                    <tr>
                                        <th scope="row"><?php echo $row->d_id; ?></th>
                                        <td><?php echo $row->description; ?></td>
                                        <td><?php echo $row->datetime; ?></td>
                                        <td><?php echo $row->status; ?></td>
                                        <td>
                                            <?php
                                                if (($row->receive_message == '') && ($row->delivery_message == '')) {
                                                    // Check if a campaign exists for this dpeople_id
                                                    $campaign_check = $obj->query("SELECT * FROM campaign WHERE dpeople_id = '$row->d_id'");
                                                    if ($campaign_check->num_rows > 0) {
                                                        // Campaign already exists
                                            ?>
                                                        <span>Already Created</span>
                                            <?php
                                                    } else {
                                                        // Campaign does not exist, show the button to create campaign
                                            ?>
                                                        <a href="create_campaign.php?delid=<?php echo $row->d_id; ?>" class="btn btn-success">Create Campaign</a>
                                            <?php
                                                    }
                                                } else {
                                            ?>
                                                    <span>Already Created</span>
                                            <?php
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <!-- Add your logic to display campaign delivery status -->
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //contact-form -->
    <!-- footer-66 -->
    <?php include 'common/footer.php'; ?>
    <!--//footer-66 -->
</body>
</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<!-- disable body scroll which navbar is in active -->

<script>
    $(function () {
        $('.navbar-toggler').click(function () {
            $('body').toggleClass('noscroll');
        })
    });
</script>
<script>
    $(window).on("scroll", function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 80) {
            $("#site-header").addClass("nav-fixed");
        } else {
            $("#site-header").removeClass("nav-fixed");
        }
    });
    //Main navigation Active Class Add Remove
    $(".navbar-toggler").on("click", function () {
        $("header").toggleClass("active");
    });
    $(document).on("ready", function () {
        if ($(window).width() > 991) {
            $("header").removeClass("active");
        }
        $(window).on("resize", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
        });
    });
</script>
<script src="assets/js/bootstrap.min.js"></script>
