<?php

session_start();
include 'common/connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:home.php');
}

// Fetch campaigns with remaining amount greater than 0
$campaign_data = $obj->query("SELECT * FROM campaign WHERE remaining_amount > 0");

// Check if the query execution failed
if ($campaign_data === false) {
    // Query execution failed, handle the error
    echo "Error executing query: " . $obj->error;
    exit; // Exit the script
}

// Check if there are no campaigns available
if ($campaign_data->num_rows === 0) {
    echo "No campaigns available for donation.";
    exit; // Exit the script
}

// Fetch donor's name based on the session user_id
$user_id = $_SESSION['user_id'];
$user_data = $obj->query("SELECT * FROM user WHERE user_id = '$user_id'");
$user = $user_data->fetch_object();
$donor_name = $user->name; // Assuming full_name is the column containing the donor's name

// Fetch the role ID of the donor
$role_id = $user->role_id;

// Check if the donation form is submitted
if (isset($_POST['submit'])) {
    $campaign_id = $_POST['campaign_id'];
    $amt = $_POST['amt'];
    $desc = $_POST['desc'];
    $date = date('Y-m-d');

    $exe = $obj->query("INSERT INTO money_donation(user_id, amount, description, date, d_name, role_id, campaign_id) 
                        VALUES ('$user_id', '$amt', '$desc', '$date', '$donor_name', '$role_id', '$campaign_id')");

    if ($exe) {
        header("location:payment.php");
    } else {
        echo "<script>alert('Error submitting donation');</script>";
    }
}
?>

<!doctype html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Helping-Hand(NGO)</title>
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <style>
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 16px;
        }
    </style>
</head>

<body>
    <?php include 'common/header.php'; ?>
    <div class="inner-banner"></div>
    <section class="w3l-contact-11">
        <div class="form-41-mian py-5">
            <div class="container py-lg-4">
                <div class="row align-form-map">
                    <div class="col-lg-12 form-inner-cont">
                        <div class="title-content text-left">
                            <h3 class="hny-title mb-lg-5 mb-4">Please Donate Money</h3>
                        </div>
                        <form method="post" class="signin-form">
                            <div class="container">
                                <div class="col-lg-10 form-input">
                                    <select name="campaign_id" required>
                                        <option value="">Select Campaign</option>
                                        <?php while ($campaign = $campaign_data->fetch_object()) { ?>
                                            <option value="<?php echo $campaign->campaign_id; ?>">
                                                <?php echo "ID: $campaign->dpeople_id - $campaign->dpeople_name"; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <input type="text" name="d_name" id="d_name" placeholder="Donor Name" required value="<?php echo $donor_name; ?>" />
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <input type="text" name="amt" id="amt" placeholder="Amount" required />
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <textarea name="desc" id="desc" placeholder="Description"></textarea>
                                </div>
                                <br>
                                <div class="submit-button text-lg-center">
                                    <button type="submit" class="btn btn-style" name="submit" id="submit">Submit</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <?php include 'common/footer.php'; ?>
</body>

</html>
