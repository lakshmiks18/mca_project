<?php 
session_start();
include 'common/connect.php';

if(!isset($_SESSION['dpeople_id']))
{
  header('location:home.php');
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = isset($_POST['email']) ? $_POST['email'] : ''; // Add isset() to avoid undefined index warning
    $contact = $_POST['contact'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : ''; // Add isset() to avoid undefined index warning
    $dob = $_POST['date'];
   

    $aadhaar = $_POST['aadhaar'];
    $aadhaar_photo_name = $_FILES['aadhaar_photo']['name'];
    $aadhaar_photo_tmp = $_FILES['aadhaar_photo']['tmp_name'];
    $aadhaar_photo_path = "upload/$aadhaar_photo_name";

    $udid = $_POST['udid'];
    $udid_photo_name = $_FILES['udid_photo']['name'];
    $udid_photo_tmp = $_FILES['udid_photo']['tmp_name'];
    $udid_photo_path = "upload/$udid_photo_name";
	$dpeople_id =  $_SESSION['dpeople_id'];

    // Insert data into database
    $exe = $obj->query("INSERT INTO dpeople(name, dob, contact_number, aadhaar_number, aadhaar_photo, udid_number, udid_photo, gender, email,user_id) VALUES ('$name','$dob','$contact','$aadhaar','$aadhaar_photo_name','$udid','$udid_photo_name','$gender','$email','$dpeople_id')");

    if ($exe) {
        move_uploaded_file($aadhaar_photo_tmp, $aadhaar_photo_path);
        move_uploaded_file($udid_photo_tmp, $udid_photo_path);

        echo "<script>alert('File Uploaded Successfully & registration successful');</script>";
        header("location:home.php");
        exit(); // Add exit() to prevent further execution
    } else {
        echo "<script>alert('Error');</script>";
    }
}
?>


<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="zxx">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Helping-Hand(NGO)</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <!-- Template CSS -->
</head>
<body>
    <!--w3l-header-->
    <?php include 'common/header.php'; ?>
    <!--/header-->
    <div class="inner-banner"></div>
    <!-- /register-form -->
    <section class="w3l-contact-11">
        <div class="form-41-mian py-5">
            <div class="container py-lg-2">
                <div class="row align-form-map">
                    <div class="col-lg-12 form-inner-cont">
                        <div class="title-content text-left">
                            <h3 class="hny-title mb-lg-5 mb-4">Application Form</h3>
                        </div>
                        <form  method="post" class="signin-form" enctype="multipart/form-data">
                            <div class="container">
                                <div class="col-lg-10 form-input">
                                    <label for="name"><h5><b>Name:</b></h5></label>
                                    <input type="text" name="name" id="name" placeholder="Name" required="" />
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <label for="date"><h5><b>Date of Birth:</b></h5></label>
                                    <input type="date" name="date" id="date" required="" />
                                </div>
                                <br>
								<div class="col-lg-10 form-input">
      <input type="email" name="email" id="email" placeholder="Email" required="" />
    </div>
    <br>
                                <div class="col-lg-10 form-input">
                                    <label for="contact"><h5><b>Contact Number:</b></h5></label>
                                    <input type="text" name="contact" id="contact" maxlength="10" placeholder="Contact Number" required="" />
                                </div>
                                <br>
                                <!-- Add Gender field -->
                                <div class="col-lg-10 form-input">
                                    <label for="gender"><h5><b>Gender:</b></h5></label>
                                    <select name="gender" id="gender" required="">
                                        <option value="">Select Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <br>
                                <!-- Add Aadhaar related fields -->
                                <div class="col-lg-10 form-input">
                                    <label for="aadhaar"><h5><b>Aadhaar Number:</b></h5></label>
                                    <input type="text" name="aadhaar" id="aadhaar" placeholder="Aadhaar Number" required="" />
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <label for="aadhaar_photo"><h5><b>Upload Aadhaar Photo:</b></h5></label>
                                    <input type="file" name="aadhaar_photo" id="aadhaar_photo" required="" />
                                </div>
                                <br>
                                <!-- Add UDID related fields -->
                                <div class="col-lg-10 form-input">
                                    <label for="udid"><h5><b>Unique Disability ID Card Number:</b></h5></label>
                                    <input type="text" name="udid" id="udid" placeholder="UDID Card Number" required="" />
                                </div>
                                <br>
                                <div class="col-lg-10 form-input">
                                    <label for="udid_photo"><h5><b>Upload UDID Card Photo:</b></h5></label>
                                    <input type="file" name="udid_photo" id="udid_photo" required="" />
                                </div>
                                <br>
                                <!-- Add other fields as needed -->
                                <div class="submit-button text-lg-center">
                                    <button type="submit" class="btn btn-style" name="submit" id="submit">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6 contact-left pr-lg-4">
                    <!-- Additional content -->
                </div>
            </div>
        </div>
    </section>
    <!-- //register-form -->
    <!-- footer-66 -->
    <?php include 'common/footer.php'; ?>
    <!--//footer-66 -->
</body>
</html>
