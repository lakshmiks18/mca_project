<?php
session_start();
include 'common/connect.php';

// Check if a donation has been made
if (isset($_POST['donate_amount'])) {
    $campaign_id = $_POST['campaign_id'];
    $donated_amount = $_POST['donated_amount'];

    // Fetch campaign details
    $campaign_data = $obj->query("SELECT * FROM campaign WHERE campaign_id = '$campaign_id'");
    $campaign = $campaign_data->fetch_object();

    // Calculate new remaining amount
    $remaining_amount = $campaign->remaining_amount - $donated_amount;

    // Update remaining amount in the database
    $update_query = $obj->query("UPDATE campaign SET remaining_amount = '$remaining_amount' WHERE campaign_id = '$campaign_id'");
    if ($update_query) {
        echo "<script>alert('Donation successful!'); window.location.href = 'home.php';</script>";
    } else {
        echo "<script>alert('Error updating remaining amount.');</script>";
    }
}

// Fetch all campaigns created by volunteers
$campaign_data = $obj->query("SELECT * FROM campaign");
?>

<!doctype html>
<html lang="zxx">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Helping-Hand(NGO)</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <?php include 'common/header.php'; ?>
    <!-- Header -->

    <!-- Inner Banner -->
    <div class="inner-banner"></div>

    <!-- Campaign Section -->
    <div class="w3l-content-5 py-5">
        <div class="container py-lg-4">
            <div class="row content-5-grids">
                <?php while($campaign = $campaign_data->fetch_object()) { ?>
                    <div class="col-lg-4 col-md-6 content-5-one">
                        <div class="content5-gd-ingf">
                            <div class="icon-holder mb-3">
                                <span class="fa fa-users service-icon" aria-hidden="true"></span>
                            </div>
                            <h4><?php echo $campaign->dpeople_name; ?></h4>
                            <p>Total Amount Required: <?php echo $campaign->amount_required; ?></p>
                            <p>Remaining Amount Required: <?php echo $campaign->remaining_amount; ?></p>
                            <p><?php echo $campaign->description; ?></p>
                            <form method="post" action="">
                                <input type="hidden" name="campaign_id" value="<?php echo $campaign->campaign_id; ?>">
                                <input type="number" name="donated_amount" placeholder="Enter donated amount" required>
                                <button type="submit" name="donate_amount" class="btn btn-style btn-primary mt-3">Donate Now</button>
                            </form>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!-- Campaign Section -->

    <!-- Footer -->
    <?php include 'common/footer.php'; ?>
    <!-- Footer -->

    <!-- Scripts -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
