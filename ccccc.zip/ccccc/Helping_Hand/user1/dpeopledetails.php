<?php 
session_start();
include 'common/connect.php';

if(!isset($_SESSION['dpeople_id']))
{
  header('location:home.php');
}

// Fetch user application details
$user_id = $_SESSION['dpeople_id'];
$result_application = $obj->query("SELECT * FROM dpeopleappli2 WHERE user_id = '$user_id'");
$row_application = $result_application->fetch_object();

?>
<!doctype html>
<html lang="zxx">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Helping-Hand(NGO)</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <!-- Template CSS -->
</head>

<body>

    <!-- Header -->
    <?php include 'common/header.php'; ?>
    <!-- Header -->

    <div class="inner-banner"></div>

    <!-- Application Details Section -->
    <section class="w3l-contact-11">
        <div class="form-41-mian py-5">
            <div class="container py-lg-2">
                <div class="row align-form-map justify-content-center">
                    <div class="col-lg-8 form-inner-cont">
                        <div class="title-content text-left">
                            <h3 class="hny-title mb-lg-5 mb-4">Application Details</h3>
                        </div>
                        <div class="container">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th>People ID:</th>
                                            <td><?php echo $row_application->dpe_id; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Name:</th>
                                            <td><?php echo $row_application->name; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email:</th>
                                            <td><?php echo $row_application->email; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact:</th>
                                            <td><?php echo $row_application->contact; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Gender:</th>
                                            <td><?php echo $row_application->gender; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of Birth:</th>
                                            <td><?php echo $row_application->dob; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Address:</th>
                                            <td><?php echo $row_application->address; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Aadhaar Number:</th>
                                            <td><?php echo $row_application->aadharcard; ?></td>
                                        </tr>
                                        <tr>
                                           <th>Aadhaar Photo:</th>
                                              <td><img src="upload/<?php echo $row_application->image; ?>" alt="Aadhaar Photo" width="100"></td>
                                         </tr>

                                        <tr>
                                            <th>UDID Card Number:</th>
                                            <td><?php echo $row_application->udidcard; ?></td>
                                        </tr>
                                        <tr>
                                            <th>UDID Card Photo:</th>
                                            <td><img src="upload/<?php echo $row_application->image1; ?>" alt="UDID Card Photo" width="100"></td>
                                        </tr>
                                        <!-- Add more rows as needed -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Application Details Section -->

    <!-- Footer -->
    <?php include 'common/footer.php'; ?>
    <!-- Footer -->

    <!-- jQuery -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Disable body scroll when navbar is active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <!-- Main navigation active class toggle -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });

        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>

</body>

</html>
