<?php 
session_start();
include 'common/connect.php';
$role = $obj->query("select * from role where not role_id='1'");

if(!isset($_SESSION['dpeople_id']))
{
  header('location:home.php');
}


if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $gender = $_POST['gender'];
    $dob = $_POST['date'];
    $aadhaar = $_POST['aadhaar'];
	$status = 'pending';
    $udid = $_POST['udid'];
    $address = $_POST['address'];
	$role_id = $_POST['role_id'];
    
	$user_id = $_SESSION['dpeople_id'];


    $filename = $_FILES['f']['name'];
    $filename_array = explode(".", $filename);
    $ext = strtolower(end($filename_array));

    $tmp = $_FILES['f']['tmp_name'];
    $path = "upload/$filename";
    
    $filename1 = $_FILES['f1']['name'];
    $filename_array1 = explode(".", $filename1);
    $ext = strtolower(end($filename_array1));

    $tmp = $_FILES['f1']['tmp_name'];
    $path = "upload/$filename1";

    if ($ext=='jpg' || $ext=='gif' || $ext=='png' || $ext=='jpeg') {
		
	$exe = $obj->query("INSERT INTO dpeopleappli2 (name, email, contact, aadharcard, udidcard, gender, dob, address, status, image, image1, user_id,role_id) VALUES ('$name', '$email', '$contact', '$aadhaar', '$udid', '$gender', '$dob', '$address',$status,'$filename', '$filename1', '$user_id','$role_id')");

if (!$exe) {
    echo "Error: " . $obj->error;
    // You can handle the error here, such as redirecting to an error page or logging the error.
} else {
    move_uploaded_file($tmp, $path);
    echo "<script>alert('File Uploaded Successfully & registration successful'); </script>";
    header("location:home.php");
}
}
}
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="zxx">


	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Helping-Hand(NGO)
		</title>
		<!-- Template CSS -->
		<link rel="stylesheet" href="assets/css/style-starter.css">
		<!-- Template CSS -->
		<link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
		<!-- Template CSS -->
	</head>

<body>

	<!--w3l-header-->

	<?php include 'common/header.php'; ?>
<!--/header-->
<div class="inner-banner">
</div>
	<!-- /register-form -->
	<section class="w3l-contact-11">
		<div class="form-41-mian py-5">
			<div class="container py-lg-2">
			  <div class="row align-form-map">
				
				<div class="col-lg-12 form-inner-cont">
					<div class="title-content text-left">
						<h3 class="hny-title mb-lg-5 mb-4">Application</h3>
					</div>
				  <form  method="post" class="signin-form" enctype="multipart/form-data">
					<div class="container">
        <div class="col-lg-10 form-input">
		<label for="name"><h5><b>Name:</b></h5></label>
      <input type="text" name="name" id="name" placeholder="Name" required="" />
    </div>
    <br>
    <div class="col-lg-10 form-input">
	<label for="email"><h5><b>Email:</b></h5></label>
      <input type="email" name="email" id="email" placeholder="Email" required="" />
    </div>
    <br>
	
    <div class="col-lg-10 form-input">
	<label for="contact"><h5><b>Contact Number:</b></h5></label>
      <input type="text" name="contact" id="contact" maxlength="10" placeholder="Contact" required="" />
    </div>
    <br>
    <div class="col-lg-10 form-checked"> 
	<label for="gender"><h5><b>Gender:</b></h5></label>
        <!--Gender -->
        <!-- Group of default radios - option 1 -->
        <div class="custom-control custom-radio">
          <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="gender" value="Male">
          <label class="custom-control-label" for="defaultGroupExample1">Male </label>
        </div>

        
        <!-- Group of default radios - option 3 -->
        <div class="custom-control custom-radio">
          <input type="radio" class="custom-control-input" id="defaultGroupExample3" name="gender" value="Female">
          <label class="custom-control-label" for="defaultGroupExample3">Female </label>
        </div>
    </div>
    <br>
    <div class="col-lg-10 form-input">
	 <label for="date"><h5><b>Date of Birth:</b></h5></label>
        
      <input type="date" name="date" id="date" placeholder="DOB" required="" />
    </div>
    <br>
    <div class="col-lg-10 form-input">
	<label for="address"><h5><b>Address:</b></h5></label>
        <textarea name="address" id="address" placeholder="Address" required="" /></textarea> 
    </div>
    <br>
	
	<div class="col-lg-10 form-input">
	<label for="aadhaar"><h5><b>Aadhaar Number:</b></h5></label>
      <input type="text" name="aadhaar" id="aadhaar" maxlength="12" placeholder="Aadhaar Number" required="" />
    </div>
    <br>
    
    <div class="col-lg-10 form-input">
	
	<label for="aadhaar_photo"><h5><b>Upload Aadhaar Photo:</b></h5></label>
      <input type="file" name="f" id="f">
    </div>
    <br>
	
	<div class="col-lg-10 form-input">
	<label for="Udid"><h5><b>UDID Card Number:</b></h5></label>
      <input type="text" name="udid" id="udid" maxlength="10" placeholder="Udid Card Number" required="" />
    </div>
    <br>
	<div class="col-lg-10 form-input">
	
	<label for="udid_photo"><h5><b>Upload Udid card Photo:</b></h5></label>
      <input type="file" name="f1" id="f1">
    </div>
    <br>
    
	<div class="col-lg-10 form-input">
       <select class="form-control"  id="role" name="role_id"> <!-- Change 'role' to 'role_id' -->
    <option value="">--Select Role--</option>
    <?php
    while($r = $role->fetch_object()) // Change '$role_id' to '$role'
    {
    ?>
    <option value="<?php echo $r->role_id;?>"><?php echo $r->role_name;?></option>
    <?php
    }
    ?>
</select>

    </div>
    <br>
    
    <div class="submit-button text-lg-center">
       <button type="submit" class="btn btn-style" name="submit" id="submit">Submit</button>
    </div>
				  </form>
				</div>

			  </div>
        <div class="col-lg-6 contact-left pr-lg-4">
          <div class="partners">
            <div class="cont-details">
            <div class="title-content text-left">
            </div><br><br>
           
            
            </div>
            <br><br><br>
            <div class="container">
              <br><br><br>
              <br><br><br><br><br><br>
            </div>
           
          </div>
          </div>
			</div>
		  </div>
		 
	  </section>

	<!-- //register-form -->
	<!-- footer-66 -->

	<?php include 'common/footer.php'; ?>
	<!--//footer-66 -->
</body>

</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<!-- disable body scroll which navbar is in active -->

<!-- disable body scroll which navbar is in active -->
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll which navbar is in active -->

<!--/MENU-JS-->
<script>
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
      $("#site-header").addClass("nav-fixed");
    } else {
      $("#site-header").removeClass("nav-fixed");
    }
  });

  //Main navigation Active Class Add Remove
  $(".navbar-toggler").on("click", function () {
    $("header").toggleClass("active");
  });
  $(document).on("ready", function () {
    if ($(window).width() > 991) {
      $("header").removeClass("active");
    }
    $(window).on("resize", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
    });
  });
</script>
<!--//MENU-JS-->
<script src="assets/js/bootstrap.min.js"></script>